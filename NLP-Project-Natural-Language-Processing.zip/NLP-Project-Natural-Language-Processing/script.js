const data={
 nbdtm:{title:"Naive Bayes — DTM",desc:"A probabilistic classifier trained on the Document-Term Matrix generated from CountVectorizer.",middle:"DTM",end:"Naive Bayes",tags:["CountVectorizer","DTM","Classification"]},
 nbtfidf:{title:"Naive Bayes — TF-IDF",desc:"Naive Bayes classification using TF-IDF features to represent term importance across documents.",middle:"TF-IDF",end:"Naive Bayes",tags:["TF-IDF","Naive Bayes","Classification"]},
 xgb:{title:"XGBoost",desc:"A gradient-boosted tree model applied to vectorized text features for classification.",middle:"Features",end:"XGBoost",tags:["Machine Learning","Boosting","Classification"]},
 lstm:{title:"LSTM",desc:"A sequence model using embeddings and recurrent layers to learn patterns across token sequences.",middle:"Embedding",end:"LSTM",tags:["Embedding","Sequence","Deep Learning"]},
 bert:{title:"BERT",desc:"A Transformer-based approach using contextual representations for NLP classification.",middle:"Tokenizer",end:"BERT",tags:["Transformer","Contextual","BERT"]}
};
document.querySelectorAll(".tabs button").forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll(".tabs button").forEach(x=>x.classList.remove("active"));btn.classList.add("active");
 const d=data[btn.dataset.model];document.getElementById("modelTitle").textContent=d.title;document.getElementById("modelDesc").textContent=d.desc;
 document.getElementById("middle").textContent=d.middle;document.getElementById("end").textContent=d.end;
 document.getElementById("tags").innerHTML=d.tags.map(x=>`<span>${x}</span>`).join("");
});
const menu=document.getElementById("menu"),nav=document.getElementById("nav");
menu.onclick=()=>nav.classList.toggle("open");
nav.querySelectorAll("a").forEach(a=>a.onclick=()=>nav.classList.remove("open"));

const theme=document.getElementById("theme");
if(localStorage.getItem("nlp-theme")==="dark"){document.body.classList.add("dark-mode");theme.textContent="🌙"}
theme.onclick=()=>{document.body.classList.toggle("dark-mode");const d=document.body.classList.contains("dark-mode");localStorage.setItem("nlp-theme",d?"dark":"light");theme.textContent=d?"🌙":"☀️"};

const ro=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("visible");ro.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(x=>ro.observe(x));

window.onscroll=()=>{
 const h=document.documentElement.scrollHeight-innerHeight;
 document.getElementById("progress").style.width=(h?scrollY/h*100:0)+"%";
};
const sections=document.querySelectorAll("main section[id]");
const links=document.querySelectorAll("nav a");
new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)links.forEach(a=>a.classList.toggle("active",a.hash==="#"+e.target.id))}),{threshold:.35}).observe;
sections.forEach(s=>new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)links.forEach(a=>a.classList.toggle("active",a.hash==="#"+e.target.id))}),{threshold:.35}).observe(s));

const tweets=[
['"Wildfire spreads rapidly across the region as emergency crews work through the night."',"DISASTER"],
['"The city marathon was cancelled because of heavy rain and flooding near the route."',"DISASTER"],
['"I finally finished my project today and celebrated with my friends!"',"NON-DISASTER"],
['"The concert was amazing and everyone had a wonderful evening."',"NON-DISASTER"]
];let ti=0;
document.getElementById("analyze").onclick=()=>{ti=(ti+1)%tweets.length;document.getElementById("tweet").textContent=tweets[ti][0];document.getElementById("prediction").textContent=tweets[ti][1]};
